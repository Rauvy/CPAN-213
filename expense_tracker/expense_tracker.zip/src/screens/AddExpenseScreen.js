import React from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const AddExpenseScreen = () => {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.headerTitle}>Add Expense</Text>
      
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.amountInput}
          placeholder="$0.00"
          placeholderTextColor="#666666"
          keyboardType="decimal-pad"
        />
        
        <TextInput
          style={styles.input}
          placeholder="Description"
          placeholderTextColor="#666666"
        />
        
        <TextInput
          style={styles.input}
          placeholder="Category"
          placeholderTextColor="#666666"
        />
      </View>

      <TouchableOpacity style={styles.addButton}>
        <Text style={styles.buttonText}>Add Expense</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
    padding: 20,
  },
  headerTitle: {
    fontSize: 24,
    color: '#ffffff',
    fontWeight: 'bold',
    marginBottom: 30,
  },
  inputContainer: {
    marginBottom: 30,
  },
  amountInput: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 15,
    fontSize: 24,
    color: '#ffffff',
    marginBottom: 15,
  },
  input: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 15,
    fontSize: 16,
    color: '#ffffff',
    marginBottom: 15,
  },
  addButton: {
    backgroundColor: '#276EF1',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
});

export default AddExpenseScreen; 