import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const StatisticsScreen = () => {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <Text style={styles.headerTitle}>Statistics</Text>
        
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Monthly Overview</Text>
          <Text style={styles.amount}>$4,523.65</Text>
          <Text style={styles.label}>Total Expenses</Text>
        </View>

        <View style={styles.categoriesContainer}>
          <Text style={styles.sectionTitle}>Top Categories</Text>
        </View>

        <View style={styles.chartContainer}>
          <Text style={styles.sectionTitle}>Spending Trend</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
  },
  headerTitle: {
    fontSize: 24,
    color: '#ffffff',
    fontWeight: 'bold',
    padding: 20,
  },
  card: {
    backgroundColor: '#1a1a1a',
    borderRadius: 15,
    padding: 20,
    margin: 20,
  },
  cardTitle: {
    fontSize: 16,
    color: '#666666',
    marginBottom: 10,
  },
  amount: {
    fontSize: 32,
    color: '#ffffff',
    fontWeight: 'bold',
  },
  label: {
    fontSize: 14,
    color: '#666666',
    marginTop: 5,
  },
  categoriesContainer: {
    padding: 20,
  },
  chartContainer: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 18,
    color: '#ffffff',
    fontWeight: '600',
    marginBottom: 15,
  },
});

export default StatisticsScreen; 